<div id="footer">
		<div class="payment_logo"><img src="<?=base_url()?>/public/images/payment_logo.jpg" /></div>
		<div class="copyright">© 2011 - 2015 GOODJOB CO., LTD</div>
</div>