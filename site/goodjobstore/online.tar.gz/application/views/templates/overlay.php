<div id="cover" style="display: block">
<div class="overlay">
	<div class="partial-home_region-overlay"></div>
    	<div class="region-selector">
            <img src="<?=base_url()?>public/images/logo.jpg" />
            <div class="directionText">Please Select a Language</div>
            <div class="coverlink">
            	<a id="coverText" href="<?=site_url('shops/lang/TH')?>">TH</a> | <a href="<?=site_url('shops/lang/EN')?>">EN</a>
            </div>
         </div>
     </div>
</div>