<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns:fb="http://ogp.me/ns/fb#">
<head>
	<title>GOODJOB</title>
	<meta name="description" content="Shop powered by PrestaShop">
	<meta name="keywords" content="shop, prestashop">
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8">
	<meta name="generator" content="GoodJobStore">
	<link rel="icon" type="<?=base_url()?>public/image/vnd.microsoft.icon" href="<?=base_url()?>public/images/favicon.png">
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>public/css/reset.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>public/css/mainstyle.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>public/css/menu.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>public/css/slidestyle.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>public/css/default.css">
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>public/css/nivo-slider.css">
	
	<script type="text/javascript" src="<?=base_url()?>public/scripts/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="<?=base_url()?>public/scripts/droplinemenu.js"></script>
	<script type="text/javascript">
		droplinemenu.buildmenu("droplinetabs1")
	</script>

	<script>
		$(document).ready(function() {
			$("#displayText").click(function () {
				$(".toggleText").toggle();
				return false;
			});
		});
	</script>
	
</head>
</head>
<body>
	<div id="wrapper">
		<!-- Header Section -->
		<?=$this->load->view('templates/header')?>
		<?php if(!$this->session->userdata('lang')): ?>
			<?=$this->load->view('templates/overlay')?>
		<?php endif; ?>
		
		<!-- Body Section -->
		<?=$contents?>

		<!-- Footer Section -->
		<?=$this->load->view('templates/footer')?>
	</div>
</body>
</html>

