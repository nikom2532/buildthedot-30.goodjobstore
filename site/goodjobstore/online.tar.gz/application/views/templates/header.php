<?php
	$login = 'Log in';
	$logout = 'Register';
	$customer_url = site_url("login");
	$logout_url = site_url("register");
	
	if($this->session->userdata('logged_in'))
	{
		$customer = $this->session->userdata('customer');
		$login = "{$customer->FirstName} {$customer->LastName}";
		$logout = 'Log out';
		$customer_url = site_url("my");
		$logout_url = site_url("logout");
		
		if(trim($customer->FirstName)=='' && trim($customer->LastName)=='')
		{
			$login = $customer->Email;
		}
	}
	
	$cart_data = get_cart_data();
?>
 <script>
		$(document).ready(function(){
		   $("#search_query_top").focusin(function(event){
			   	var keyword = $(this).val();
		   		if(keyword==='Enter Keyword')
		   		{
			   		$(this).val('');	
		   		}
		   		$('#searching').attr('style',"background: black !important;");
		   });
		   
		   $("#search_query_top").focusout(function(event){
		   		var keyword = $(this).val();
		   		if(keyword==='')
		   		{
			   		$(this).val('Enter Keyword');	
		   		}
		   		$('#searching').attr('style','');
		   });
		 });   
	</script>
<!-- Header Section -->
<div id="header">
	<div class="logo"><a href="<?=site_url()?>"><img src="<?=base_url()?>public/images/logo.jpg" /></a></div>
	<div class="right">
		<table>
			<tbody>
				<tr>
					<td style="vertical-align:middle">
						<div id="member">
							<ul class="member_style">
								<li class="line"><a href="<?=$customer_url?>"><?=$login?></a></li> 
								<li><a href="<?=$logout_url?>"><?=$logout?></a></li>
							</ul>
						</div>
					</td>
					<td>
						<div id="search">
							<form method="post" action="<?=site_url('shops/searching')?>" id="searchbox">
								<input type="hidden" name="orderby" value="position">
								<input type="hidden" name="orderway" value="desc">
					            <input type="submit" name="submit_search" value="Search" class="submit_search" id="searching">
					            <input class="search_query ac_input" type="text" id="search_query_top" name="search_query" value="Enter Keyword" autocomplete="off">
							</form>
						</div>
					</td>
				</tr>
			</tbody>
		</table>	
		<div id="language">
			<span class="guide"><a href="payment-guide.php ">Shopping Guide</a></span>
				<ul>
				<?php if(LANG=='TH'): ?>
					<li class="select first">TH</li>
					<li><a href="<?=site_url('shops/lang/EN')?>">EN</a></li>
				<?php else: ?>
					<li class="first"><a href="<?=site_url('shops/lang/TH')?>">TH</a></li>
					<li class="select">EN</li>
				<?php endif; ?>
				</ul>
		</div>
	</div>
</div>
<!-- Navigation Section -->
<div id="nav">
	<div id="droplinetabs1" class="droplinetabs">
	<?php 
		$main_navigation = get_all_main_navigation();
	?>
		<ul>
			<?php foreach($main_navigation as $key_main => $main_navigations): ?>
				<li>
				<?php if(LANG=='TH'): ?>
					<a href="<?=site_url("{$this->config->item('cat')}/{$main_navigations->main_url}")?>" title=""><?=$main_navigations->Name_Th?></a>
				<?php else: ?>
					<a href="<?=site_url("{$this->config->item('cat')}/{$main_navigations->main_url}")?>" title=""><?=$main_navigations->Name_En?></a>
				<?php endif; ?>
					
					<?php $sub_navigation = get_all_sub_menu_navigation($main_navigations->main_ID);  ?>
					<?php if(!empty($sub_navigation)): ?>
						<ul>
						<?php foreach($sub_navigation as $key => $value): ?>
						<?php if(LANG=='TH'): ?>
							<li><a href="<?=site_url("{$this->config->item('cat')}/{$main_navigations->main_url}/{$value->sub_url}")?>"><?=$value->Name_Th?></a></li>
						<?php else: ?>
							<li><a href="<?=site_url("{$this->config->item('cat')}/{$main_navigations->main_url}/{$value->sub_url}")?>"><?=$value->Name_En?></a></li>
						<?php endif; ?>
						<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<!--<ul>
			<li class="first">
				<a href="#" title="">New Arrivals</a>
					<ul>
						<li><a href="#">Spacial</a></li>
						<li><a href="#">Corporate Gift</a></li>
						<li><a href="#">Skirt</a></li>
						<li><a href="#">Notebook case</a></li>
					</ul>
			</li>
			<li><a href="#" title="">Stationery</a></li>
			<li>
				<a href="#" title="">Bags & Accessories</a>
					<ul>
						<li><a href="#">Document Bag </a></li>
						<li><a href="#">Presentation Bag </a></li>
						<li><a href="#">Laptop Bag</a></li>
						<li><a href="#">Wine Holder</a></li>
						<li><a href="#">Tissue Holder</a></li>
					</ul>
			</li>
			<li><a href="#" title="">Awesome</a></li>
			<li><a href="#" title="">Designers' tools</a></li>
			<li><a href="#" title="" class="last">Sales</a></li>
		</ul>-->
		
	</div>
	<div id="shopping_info">
		<a id="displayText" href="#"><img src="<?=base_url()?>public/images/cart.jpg" align="absmiddle" />Shopping Cart</a>
		<a href="<?=site_url('shops/locator')?>"><img src="<?=base_url()?>public/images/location.jpg" align="absmiddle" />Store Locator</a>
		
		<div id="toggleText" class="toggleText" style="display: none">
		<?php foreach($cart_data as $result): ?>
			<div class="left">
				<img class="imgToggle" src="<?=base_url()?>public/<?=$result->images_Thumbnail_path?>" />
			</div>
			<div class="right">
				<?=(LANG=='TH')?$result->products_Pro_Name_Th:$result->products_Pro_Name_En?>
				<table width="150px">
					<tbody>
						<tr>
							<td>SIZE</td>
							<td class="tr"><?=$result->products_Size?></td>
						</tr>
						<tr>
							<td>Qty</td>
							<td class="tr"><?=$result->cart_Qty?> x <?=($result->products_Price_sale!=0)?number_format($result->products_Price_sale):number_format($result->products_Price_Buy);?> ฿</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="price_total">TOTAL  <span class="textRight"><?=($result->products_Price_sale!=0)?number_format($price_arr[] = $result->products_Price_sale*$result->cart_Qty):number_format($price_arr[] = $result->products_Price_Buy*$result->cart_Qty);?> ฿</span></div>
		<?php endforeach; ?>
			<a href="<?=site_url('cart')?>">VIEW SHOPPING CART</a>
		</div>
	</div>
</div>

<div id="breadcrumbs">
<?php if(isset($nav_arr)): ?>
	<?php foreach($nav_arr as $key => $value): ?>
		<?php if($value['current']==TRUE && $value['name'] != $this->config->item('cat')): ?>
			<li class="current"><?=$value['name']?></li>
		<?php elseif($value['name'] != $this->config->item('cat')): ?>
			<li><a href="<?=$value['link']?>"><?=$value['name']?></a></li>
		<?php elseif($value['name'] == $this->config->item('cat')): ?>
			<li><a href="<?=site_url()?>">HOME</a></li>
		<?php endif; ?>
	<?php endforeach; ?>
<?php else: ?>
	<?php if(isset($nav_1)): ?>
	<ul>
		<li><a href="<?=site_url()?>">Home</a></li>
		<?php if($nav_1['current']==TRUE): ?>
			<li class="current"><?=$nav_1['name']?></li>
		<?php else: ?>
			<li><a href="<?=$nav_1['link']?>"><?=$nav_1['name']?></a></li>
		<?php endif; ?>
		
		<?php if(isset($nav_2)): ?>
			<?php if($nav_2['current']==TRUE): ?>
				<li class="current"><?=$nav_2['name']?></li>
			<?php else: ?>
				<li><a href="<?=$nav_2['link']?>"><?=$nav_2['name']?></a></li>
			<?php endif; ?>
		<?php endif; ?>
		
		<?php if(isset($nav_3)): ?>
			<?php if($nav_3['current']==TRUE): ?>
				<li class="current"><?=$nav_3['name']?></li>
			<?php else: ?>
				<li><a href="<?=$nav_3['link']?>"><?=$nav_3['name']?></a></li>
			<?php endif; ?>
		<?php endif; ?>
	</ul>
	<?php endif; ?>
<?php endif; ?>
</div>