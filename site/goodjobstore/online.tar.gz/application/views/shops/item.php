<base href="<?=base_url()?>public/" />
	<link rel="stylesheet" type="text/css" href="<?=base_url()?>public/css/product.css" media="screen" />

<!-- jqZoom -->
    <link rel="stylesheet" href="<?=base_url()?>public/css/jquery.jqzoom.css" type="text/css">	
	<script src="<?=base_url()?>public/scripts/jquery-1.6.js" type="text/javascript"></script>
	<script src="<?=base_url()?>public/scripts/jquery.jqzoom-core.js" type="text/javascript"></script>
	<script type="text/javascript">
	</script>
	
	<script type="text/javascript">
		function testtest()
		{
			$('.jqzoom').jqzoom({
	            zoomType: 'standard',
	            lens:true,
	            preloadImages: true,
	            alwaysOn:false
	        });
		}
		
		function demo()
		{
			$(".zoomWrapperImage").remove();
		}

		function testtest1(id)
		{
			$('.testtest'+id).attr('dir', function(i, val) {
				$('#testjqzoom').attr('href', val);
				
				$('.testtest'+id).attr('title', function(i, val1) {
					$('#input_pic').attr('src', val1);
				
					$(".jqZoomWindow").remove();
					$(".jqZoomPup").remove();
					$(".jqzoom").remove();
						  
					$("#new_data").remove();
					$("#testbeta").html('<div class="clearfix" id="new_data"></div>');
					$('#new_data').append('<a href="'+val+'" class="hoverproduct"><img id="input_pic" src="'+val1+'" id="main-product-image" /></a>');
						 
					// reload jQZoom after switching image
					$(".hoverproduct").jqzoom({
						zoomWidth: 550,
						zoomHeight: 500,
						title: false
					});
				});			  
			});
		}
	</script>

	<script>

		function changeImage(select_color)
		{
			viewDescrip('<?=$product_id?>',select_color);
		}

		function filterColor(filter_Color)
		{
			viewItem('<?=$product_id?>',filter_Color);
			viewDescrip('<?=$product_id?>',filterProp);
		}

	</script>

	<!-- connect Database -->
	<script src="<?=base_url()?>public/scripts/ajax.item.java" type="text/javascript"></script>

		<script>
			viewItem('<?=$product_id?>','');
			viewDescrip('<?=$product_id?>','');
		</script>
		<!-- Body Section -->
		<div id="product_content">
			<!-- Product Zoom-->
			<div id="productZoom">
				<div class="clearfix" id="content">
					<!-- view Item -->
				</div>
			</div>

			<!-- Product Detail -->
			<div id="productDetail">
				<!-- view Description -->
			</div>
		</div>