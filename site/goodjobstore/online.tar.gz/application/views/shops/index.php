    <script type="text/javascript" src="<?=base_url()?>public/scripts/jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript">
    	$(document).ready(function() {
    		$('#slider').nivoSlider();
    	});
    </script>
<div id="section">
	<?php if($promotions['status']==1): ?>
		<div id="promotion">
			<div class="promo-head"><?=(LANG=='TH')?$promotions['data']->name_th:$promotions['data']->name_en;?></div>
				<!--<center><img src="<?=base_url()?>public/<?=$promotions['data']->path?>" /></center>
			<div class="promo-footer"></div>-->
		</div>
	<?php endif; ?>
	
	<!-- Article Section -->
	<div id="article">
		<div class="slider-wrapper theme-default">
	        <div class="ribbon"></div>
	            <div id="slider" class="nivoSlider">
					<?php foreach($slideshows as $slideshow): ?>
						<a href= '#'><img src='<?=base_url()?>public/<?=$slideshow->Path?>' alt='' /></a>
					<?php endforeach; ?>
	            </div>
		</div>
	</div>
	
	<!-- Aside Section -->
	<div id="aside">
		<ul>
			<?php foreach($banners as $key => $banner): ?>
				<li <?=($key==0)?"class='boarder_img'":''?>>
					<img src='<?=base_url()?>public/<?=$banner->Thumbnail_path?>' class='center' />
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>