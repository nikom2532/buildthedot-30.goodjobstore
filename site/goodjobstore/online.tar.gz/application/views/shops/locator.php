<style>
 #title_head {
	 clear:both;
	 text-transform: uppercase;
	 color: #000;
	 font-size: 28px;
	 font-weight: bold;
	 font-family: Arial, Helvetica, sans-serif;
	 margin-top: 20px;
 }
 
 hr {
	 margin-top: 25px;
	 margin-bottom: 15px;
	 border: 1px solid #cccccc;
 }
 
 p {
 	color: #000;
	font-size: 16px;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	line-height: 25px;
 }
</style>

<div id="title_head">STORE LOCATOR</div>
<hr>
<div style="float:left; width:60%;">
	<img width="100%" src="<?=base_url()?>public/images/locator.jpg" />
</div>
<div style="margin-right:-15px;margin-left:15px;float:right; width:40%;">
	<p>
		VISIT US DIALY AT
	</p>
	<p>
		SIAM DISCOVERY 4th FLOOR
	</p>
	<p>
		10.00 AM - 10.00 PM
	</p>
	<p>
		CALL US 02-683-5660
	</p>
</div>
<div class="clear"><br></div>