<link rel="stylesheet" type="text/css" href="<?=base_url()?>public/css/login.css">

		<!-- Welcom Section-->
		<div id="welcome">
			Welcome to Goodjob
		</div>
		<!-- Body Section -->
		<div id="content">
			<div id="signin">
				<span class="headerblock">
					Sign in
					<div class="smalltext">Please sign in to view or updates your Shopping Gag and Wishlist</div>
						<?php  
							if(isset($error_login))
							{
								echo "<font color={$error_login['color']}>";
								foreach ($error_login['data'] as $key => $value) 
								{
									echo "<p style='line-height:115%;'>{$value}</p>";
								}
								echo '</font>';
							}
						?>
					<?=form_open('auth/verify')?>
						<div id="textbox_name">Email</div>
						<input type="text" name="email" />
						<div id="textbox_name">Password</div>
						<input type="password" name="password" />
						<div class="forgetpassword"><a href="#">Forget your password?</a></div>
						<input type="submit" name="sign_in" value="SIGN IN" class="button"/>
					<?=form_close()?>
				</span>
			</div>
			<div id="signup">
				<span class="headerblock">
					Create an account
					<div class="smalltext">Register here to create your personal Shopping Bag and Wishlist</div>
						<?php  
							if(isset($error))
							{
								echo "<font color={$error['color']}>";
								foreach ($error['data'] as $key => $value) 
								{
									echo "<p style='line-height:115%;'>{$value}</p>";
								}
								echo '</font>';
							}
						?>
					<?=form_open('auth/registration')?>
						<div id="textbox_name">Email</div>
						<input type="text" name="Email" />
						<div id="textbox_name">Password</div>
						<input type="password" name="Password" /> 
						<div class="notice">(Must be at least 4 character long)</div>
						<div id="textbox_name">Confirm Password</div>
						<input type="password" name="Password2" /> 

						<div class="newsletter">
							<input type="checkbox" name="newsletter" value="1" /> Sign me up for newsletter.
							<div class="register_button"><input type="submit" name="sign_up" value="Rigister Now" class="button"/></div>
						</div>
					<?=form_close()?>
				</span>
			</div>
		</div>