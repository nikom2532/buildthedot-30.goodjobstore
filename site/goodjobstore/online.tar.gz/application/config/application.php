<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
|--------------------------------------------------------------------------
| Application name
|--------------------------------------------------------------------------
*/

//$config['app_name']	= "Example Application";
//$config['app_title'] = "";


/*
|--------------------------------------------------------------------------
| Version
|--------------------------------------------------------------------------
*/
$config['version']	= "1.0.0";

/*
|--------------------------------------------------------------------------
| Debug
|--------------------------------------------------------------------------
*/
$config['debug']	= TRUE;

$config['cat']	= 'category';


$config['email_from']	= 'info@goodjobstore.com';
$config['email_name']	= 'GOODJOB';

/* End of file application.php */
/* Location: ./application/config/application.php */
