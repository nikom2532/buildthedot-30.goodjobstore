<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Auth extends MY_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	function index()
	{
		
	}
	
	function login()
	{
		if($this->session->userdata('logged_in'))
		{
			redirect('my');
		}
		
		$data['nav_1'] = array('name'=>'Login', 'link'=>site_url('login'), 'current'=>TRUE);
		$this->template->view('auth/login', $data);
	}
	
	function verify() 
	{
		$query = $this->db->get_where('customers', array('Email'=>$this->input->post('email') , 'Password'=>$this->input->post('password')))->row();
		if(empty($query))
		{
			$error[] = "The email or password you entered is incorrect.";
			$data['error_login'] = array('data'=>$error, 'color'=>'red');
			$data['nav_1'] = array('name'=>'Login', 'link'=>site_url('login'), 'current'=>TRUE);
			$this->template->view('auth/login', $data);
			return;
		}
		else
		{
			$this->session->set_userdata('customer', $query);
			$this->session->set_userdata('logged_in', TRUE);
			$this->_update_cart_from_session();
			redirect('my');
		}
	}
	
	function _update_cart_from_session()
	{
		$customer_id = $this->session->userdata('customer')->Cus_ID;
		//echo $this->session->userdata('session_id');
		
		$by_session = $this->db->get_where('cart', array('Session_ID'=>$this->session->userdata('session_id')))->result();
		foreach ($by_session as $key => $value) 
		{
			//var_dump($value);
			//echo "<br/><br/>";
			$by_id = $this->db->get_where('cart', array('Cus_ID'=>$customer_id, 'Color_ID'=>$value->Color_ID, 'Product_ID'=>$value->Product_ID))->row();
			
			if(isset($by_id->Cart_ID))
			{
				$this->db->where('Cart_ID', $by_id->Cart_ID);
				$this->db->update('cart', array('Qty' => $by_id->Qty + $value->Qty ));	
				
				$this->db->delete('cart', array('Cart_ID'=>$value->Cart_ID));	
			}
			else
			{
				$this->db->where('Cart_ID', $value->Cart_ID);
				$this->db->update('cart', array('Cus_ID' => $customer_id, 'Session_ID'=>NULL ));
			}
		}
		return;
	}

	function register()
	{
		if($this->session->userdata('logged_in'))
		{
			redirect('my');
		}
		$data['nav_1'] = array('name'=>'Register', 'link'=>site_url('login'), 'current'=>TRUE);
		$this->template->view('auth/login', $data);
	}
	
	function registration()
	{
		$data['nav_1'] = array('name'=>'Register', 'link'=>site_url('login'), 'current'=>TRUE);
		if(!$this->input->post('Email'))
		{
			$error[] = "Email is missing!";
		}
		
		if(!$this->input->post('Password'))
		{
			$error[] = "Password is missing!";
		}
		
		if(strlen($this->input->post('Password')) < 4)
		{
			$error[] = "Password is to short, 4 characters min!";
		}
		
		if(!$this->input->post('Password2'))
		{
			$error[] = "Please repeat your password!";
		}
		
		if($this->input->post('Password') != $this->input->post('Password2'))
		{
			$error[] = "Your passwords do not match!";
		}
		
		if(isset($error))
		{
			$data['error'] = array('data'=>$error, 'color'=>'red');
			$this->template->view('auth/login', $data);
		}
		else
		{
			$query = $this->db->get_where('customers', array('Email'=>$this->input->post('Email')))->row();
			if(!empty($query))
			{
				$error[] = "This Email is already exist.";
				$data['error'] = array('data'=>$error, 'color'=>'red');
				$this->template->view('auth/login', $data);
			}
			else
			{
				$this->db->order_by('Cus_ID', 'desc');
				$query = $this->db->get('customers')->row()->Cus_ID;
				
				$id = str_replace('P','',$query);
				$Cus_ID = 'P'.sprintf("%05d",$id+1);
				
				$customer = array(
					'Cus_ID' => $Cus_ID,
					'Email' => $this->input->post('Email'),
					'Password' => $this->input->post('Password'),
					'newsletter' => $this->input->post('newsletter')
				);
				$this->db->insert('customers', $customer);
				
				$data['error'] = array('data'=> array('Register was succesful.') , 'color'=>'green');
				$this->template->view('auth/login', $data);
			}
		}
		
	}
	
	function logout()
	{
		$this->session->sess_destroy();
		redirect();
	}
	
	function testmail()
	{
		send_mail_helper('info@goodjob.com','GOODJOB','boy@codefriday.com', 'test', 'body');
	}

}

/* End of file auth.php */
/* Location: ./application/controllers/auth.php */