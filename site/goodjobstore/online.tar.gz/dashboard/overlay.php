
<div id="cover" style="display: block">
<div class="overlay">
	<div class="partial-home_region-overlay"></div>
    	<div class="region-selector">
            <img src="images/logo.jpg" />
            <div class="directionText">Please Select a Language</div>
            <div class="coverlink">
            	<a id="coverText" href="javascript:toggle();">TH</a> | <a href="#">EN</a>
            </div>
         </div>
</div>
</div>