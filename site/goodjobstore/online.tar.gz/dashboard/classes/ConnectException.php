<?php
class ConnectException extends Exception
{

}
?>