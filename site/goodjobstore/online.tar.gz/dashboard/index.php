<?php 
session_start();
if(!isset($_SESSION['Cus']))
 $_SESSION['Cus']=null;

//Slide Show
include_once 'classes/Images.php';
$slide = new Images();
$show = $slide-> selectSlide(); 
$banner = $slide->selectBanner();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
<head>
	<title>GOODJOB</title>
	<meta name="description" content="Shop powered by PrestaShop">
	<meta name="keywords" content="shop, prestashop">
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=utf-8">
	<meta name="generator" content="GoodJobStore">
	<link rel="icon" type="image/vnd.microsoft.icon" href="images/favicon.png">
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/mainstyle.css">
	<link rel="stylesheet" type="text/css" href="css/menu.css">
	<link rel="stylesheet" type="text/css" href="css/slidestyle.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="css/default.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="css/nivo-slider.css" media="screen" />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
	<script src="scripts/droplinemenu.js" type="text/javascript"></script>
	<script type="text/javascript">
		//build menu with DIV ID="myslidemenu" on page:
		droplinemenu.buildmenu("droplinetabs1")
	</script>

	<script type="text/javascript" src="scripts/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="scripts/jquery.nivo.slider.pack.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>
	<? include("script-menu.php"); ?>

</script>
</head>
<body>
	<div id="wrapper_index">
		<!-- Header Section -->
		<? include("header.php"); ?>
		<? //include("overlay.php"); ?>
		<!-- Body Section -->
		<div id="section">
			<div id="promotion">
				<div class="promo-head">FREE SHIPING Everywhere in Thailand</div>
				<center><img src="images/promotion.png" /></center>
				<div class="promo-footer"></div>
			</div>
			<!-- Article Section -->
			<div id="article">
				<div class="slider-wrapper theme-default">
		            <div class="ribbon"></div>
			            <div id="slider" class="nivoSlider">
							<?php
								echo $slide->getSlideShow();
							?>
			            </div>
	        	</div>
			</div>
			<!-- Aside Section -->
			<div id="aside">
				<ul>
					<?php
						echo $slide->getBanner();
					?>
				</ul>
			</div>
		</div>

		<!-- Footer Section -->
		<? include("footer.php"); ?>
	</div>
</body>
</html>
